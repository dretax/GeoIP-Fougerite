<?php
header('Content-Type:text/plain');
ini_set('display_errors', 'on');
include './db_connect.php';

if (isset($_GET['ip']) && $_GET['ip'] != '') {
    echo "Selected IP address: ".$_GET['ip'].PHP_EOL;
    echo "Converted to LONG INT by PHP's ip2long(): ".ip2long($_GET['ip']).PHP_EOL;
    
    $selip = $db->prepare("SELECT INET_ATON(?) AS ip");
    $selip->execute(array($_GET['ip']));
    $test = $selip->fetch(PDO::FETCH_ASSOC);
    
    echo "Converted to LONG INT by MySQL's INET_ATON(): ".$test['ip'].PHP_EOL;
    echo PHP_EOL.PHP_EOL;
    echo "Trying to select told 'old' way.. (INET_ATON inside the Query):".PHP_EOL;
    echo "SELECT COUNT(*) AS num, result FROM CityData WHERE INET_ATON('".$_GET['ip']."') BETWEEN range_start AND range_end".PHP_EOL;
    $geoip = $db->prepare("SELECT COUNT(*) AS num, result FROM CityData WHERE INET_ATON(?) BETWEEN range_start AND range_end");
    $geoip->execute(array($_GET['ip']));
    $data = $geoip->fetch(PDO::FETCH_ASSOC);
    if ($data['num'] != 1) {
        echo 'Invalid IP or data not found'.PHP_EOL;
    }
    else {
        echo $data['result'].PHP_EOL;
    }
    echo PHP_EOL.PHP_EOL;
    echo "Trying to select a different way.. (MySQL's result in Query):".PHP_EOL;
    echo "SELECT COUNT(*) AS num, result FROM CityData WHERE ".$test['ip']." BETWEEN range_start AND range_end".PHP_EOL;
    $geoip = $db->prepare("SELECT COUNT(*) AS num, result FROM CityData WHERE ? BETWEEN range_start AND range_end");
    $geoip->execute(array($test['ip']));
    $data = $geoip->fetch(PDO::FETCH_ASSOC);
    if ($data['num'] != 1) {
        echo 'Invalid IP or data not found'.PHP_EOL;
    }
    else {
        echo $data['result'].PHP_EOL;
    }
    echo PHP_EOL.PHP_EOL;
    echo "Trying to select yet another way.. (PHP's result in Query):".PHP_EOL;
    echo "SELECT COUNT(*) AS num, result FROM CityData WHERE ".ip2long($_GET['ip'])." BETWEEN range_start AND range_end".PHP_EOL;
    $geoip = $db->prepare("SELECT COUNT(*) AS num, result FROM CityData WHERE ? BETWEEN range_start AND range_end");
    $geoip->execute(array(ip2long($_GET['ip'])));
    $data = $geoip->fetch(PDO::FETCH_ASSOC);
    if ($data['num'] != 1) {
        echo 'Invalid IP or data not found'.PHP_EOL;
    }
    else {
        echo $data['result'].PHP_EOL;
    }
}
else {
    echo 'Invalid IP or data not found';
}