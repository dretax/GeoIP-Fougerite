<?php
header('Content-Type:text/plain');
include './db_connect.php';

if (isset($_GET['ip']) && $_GET['ip'] != '') {
    $geoip = $db->prepare("SELECT COUNT(*) AS num, result FROM CityData WHERE INET_ATON(?) BETWEEN range_start AND range_end");
    $geoip->execute(array($_GET['ip']));
    $data = $geoip->fetch(PDO::FETCH_ASSOC);
    if ($data['num'] != 1) {
        echo 'Invalid IP or data not found';
    }
    else {
        echo $data['result'];
    }
}
else {
    echo 'Invalid IP or data not found';
}