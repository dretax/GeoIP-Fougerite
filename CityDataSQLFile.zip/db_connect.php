<?php
$db = new PDO('mysql:host=localhost;dbname=DATABASE_NAME', 'MYSQL_USERNAME', 'MYSQL_PASSWORD');